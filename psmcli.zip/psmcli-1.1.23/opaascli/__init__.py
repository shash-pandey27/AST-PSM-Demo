# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
__version__ = '1.1.23'